import os
toolkit = 'wx'
os.environ['ETS_TOOLKIT'] = toolkit

from enthought.traits.api import HasTraits
from enthought.traits.ui.api import View, Item
from enthought.savage.traits.ui.svg_button import SVGButton

from os.path import dirname, join, abspath
FILE_DIRECTORY = dirname(abspath(__file__))
RESOURCE_PATH = join(FILE_DIRECTORY, 'resource/')

if toolkit == 'qt4':
    pause_icon = join(RESOURCE_PATH, 'player_pause.svgz')
    resume_icon = join(RESOURCE_PATH, 'player_play.svgz')
else:
    pause_icon = join(RESOURCE_PATH, 'player_pause.svg')
    resume_icon = join(RESOURCE_PATH, 'player_play.svg')

class SVGDemo(HasTraits):

    pause = SVGButton('Pause', filename=pause_icon,
                      toggle_filename=resume_icon,
                      toggle_state=True,
                      toggle_label='Resume',
                      toggle_tooltip='Resume',
                      tooltip='Pause', toggle=True)

    trait_view = View(Item('pause'))

SVGDemo().configure_traits()
